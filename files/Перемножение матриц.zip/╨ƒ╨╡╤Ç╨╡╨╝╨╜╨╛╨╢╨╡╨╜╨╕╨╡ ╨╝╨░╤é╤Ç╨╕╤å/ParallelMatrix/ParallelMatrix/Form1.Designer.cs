﻿namespace ParallelMatrix
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.bCalculate = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.dgvMatrixA = new System.Windows.Forms.DataGridView();
            this.bCreateMatrix = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbM = new System.Windows.Forms.TextBox();
            this.tbN = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dgvMartixB = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.dgvMatrixC = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.bCalculateParallel = new System.Windows.Forms.Button();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatrixA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMartixB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatrixC)).BeginInit();
            this.SuspendLayout();
            // 
            // bCalculate
            // 
            this.bCalculate.Enabled = false;
            this.bCalculate.Location = new System.Drawing.Point(704, 761);
            this.bCalculate.Name = "bCalculate";
            this.bCalculate.Size = new System.Drawing.Size(218, 91);
            this.bCalculate.TabIndex = 0;
            this.bCalculate.Text = "Вычислить последовательно";
            this.bCalculate.UseVisualStyleBackColor = true;
            this.bCalculate.Click += new System.EventHandler(this.bCalculate_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(704, 633);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(339, 122);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // dgvMatrixA
            // 
            this.dgvMatrixA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMatrixA.Location = new System.Drawing.Point(12, 146);
            this.dgvMatrixA.Name = "dgvMatrixA";
            this.dgvMatrixA.RowTemplate.Height = 33;
            this.dgvMatrixA.Size = new System.Drawing.Size(670, 427);
            this.dgvMatrixA.TabIndex = 2;
            // 
            // bCreateMatrix
            // 
            this.bCreateMatrix.Location = new System.Drawing.Point(763, 23);
            this.bCreateMatrix.Name = "bCreateMatrix";
            this.bCreateMatrix.Size = new System.Drawing.Size(225, 53);
            this.bCreateMatrix.TabIndex = 3;
            this.bCreateMatrix.Text = "Создать матрицы";
            this.bCreateMatrix.UseVisualStyleBackColor = true;
            this.bCreateMatrix.Click += new System.EventHandler(this.bCreateMatrix_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "M =";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "N = ";
            // 
            // tbM
            // 
            this.tbM.Location = new System.Drawing.Point(66, 17);
            this.tbM.Name = "tbM";
            this.tbM.Size = new System.Drawing.Size(601, 31);
            this.tbM.TabIndex = 6;
            this.tbM.Text = "1200";
            // 
            // tbN
            // 
            this.tbN.Location = new System.Drawing.Point(66, 58);
            this.tbN.Name = "tbN";
            this.tbN.Size = new System.Drawing.Size(601, 31);
            this.tbN.TabIndex = 7;
            this.tbN.Text = "100";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(184, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "Часть матрицы A";
            // 
            // dgvMartixB
            // 
            this.dgvMartixB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMartixB.Location = new System.Drawing.Point(704, 146);
            this.dgvMartixB.Name = "dgvMartixB";
            this.dgvMartixB.RowTemplate.Height = 33;
            this.dgvMartixB.Size = new System.Drawing.Size(676, 427);
            this.dgvMartixB.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(699, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(184, 25);
            this.label4.TabIndex = 10;
            this.label4.Text = "Часть матрицы B";
            // 
            // dgvMatrixC
            // 
            this.dgvMatrixC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMatrixC.Location = new System.Drawing.Point(12, 633);
            this.dgvMatrixC.Name = "dgvMatrixC";
            this.dgvMatrixC.RowTemplate.Height = 33;
            this.dgvMatrixC.Size = new System.Drawing.Size(670, 427);
            this.dgvMatrixC.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 605);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(341, 25);
            this.label5.TabIndex = 12;
            this.label5.Text = "Часть результирующей матрицы";
            // 
            // bCalculateParallel
            // 
            this.bCalculateParallel.Enabled = false;
            this.bCalculateParallel.Location = new System.Drawing.Point(1059, 761);
            this.bCalculateParallel.Name = "bCalculateParallel";
            this.bCalculateParallel.Size = new System.Drawing.Size(218, 91);
            this.bCalculateParallel.TabIndex = 13;
            this.bCalculateParallel.Text = "Вычислить параллельно";
            this.bCalculateParallel.UseVisualStyleBackColor = true;
            this.bCalculateParallel.Click += new System.EventHandler(this.bCalculateParallel_Click);
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(1059, 633);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(321, 122);
            this.richTextBox2.TabIndex = 14;
            this.richTextBox2.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1421, 1082);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.bCalculateParallel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dgvMatrixC);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dgvMartixB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbN);
            this.Controls.Add(this.tbM);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bCreateMatrix);
            this.Controls.Add(this.dgvMatrixA);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.bCalculate);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatrixA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMartixB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatrixC)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bCalculate;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.DataGridView dgvMatrixA;
        private System.Windows.Forms.Button bCreateMatrix;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbM;
        private System.Windows.Forms.TextBox tbN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgvMartixB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgvMatrixC;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button bCalculateParallel;
        private System.Windows.Forms.RichTextBox richTextBox2;
    }
}

