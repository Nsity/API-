﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Threading;

namespace ParallelMatrix
{
    public partial class Form1 : Form
    {

        int N;
        int M;

        double[,] MatrixA;
        double[,] MatrixB;

        public Form1()
        {
            InitializeComponent();
        }


        

        private void bCreateMatrix_Click(object sender, EventArgs e)
        {
            N = Convert.ToInt32(tbN.Text);
            M = Convert.ToInt32(tbM.Text);

            MatrixA = new double[M, N];
            MatrixB = new double[N, M];

            for (int i = 0; i < M; i++)
                for (int j = 0; j < N; j++)
                {
                    MatrixA[i, j] = i + j;
                }

            for (int i = 0; i < N; i++)
                for (int j = 0; j < M; j++)
                {
                    MatrixB[i, j] = (i - j) * 5;
                }

            printMatrix(dgvMatrixA, MatrixA);
            printMatrix(dgvMartixB, MatrixB);

            bCalculate.Enabled = true;
            bCalculateParallel.Enabled = true;

        }

        private void bCalculate_Click(object sender, EventArgs e)
        {
            MultiplicationMatrix multiplicationMatrix = new MultiplicationMatrix(MatrixA, MatrixB);

            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();
            double[,] MatrixC = multiplicationMatrix.Multiplication();
            stopWatch.Stop();

            richTextBox1.Text = Convert.ToString(stopWatch.Elapsed.TotalSeconds);

            printMatrix(dgvMatrixC, MatrixC);

        }

        private void bCalculateParallel_Click(object sender, EventArgs e)
        {
            MultiplicationMatrix multiplicationMatrix = new MultiplicationMatrix(MatrixA, MatrixB);

            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();
            double[,] MatrixC = multiplicationMatrix.MultiplicationParallel();
            stopWatch.Stop();

            richTextBox2.Text = Convert.ToString(stopWatch.Elapsed.TotalSeconds);

            printMatrix(dgvMatrixC, MatrixC);

        }


        void printMatrix(DataGridView datagridView, double[,] matrix)
        {
            int Count = 10;
            datagridView.ColumnCount = Count;
            datagridView.RowCount = Count;
            
            for (int i = 0; i < Count; i++)
                for (int j = 0; j < Count; j++)
                {
                    datagridView.Rows[i].Cells[j].Value = matrix[i, j];
                }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
            Task.Factory.StartNew(() =>
            {
                cancellationTokenSource.Cancel();
            });

            ParallelOptions parallelLoopOptions = new ParallelOptions()
            {
                CancellationToken = cancellationTokenSource.Token
            };
        }

    }
}
