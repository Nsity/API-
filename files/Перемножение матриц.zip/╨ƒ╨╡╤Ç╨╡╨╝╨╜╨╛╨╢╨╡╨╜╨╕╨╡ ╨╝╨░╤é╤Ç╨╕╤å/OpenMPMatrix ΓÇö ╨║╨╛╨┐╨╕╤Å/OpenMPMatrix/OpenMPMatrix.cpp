// OpenMPMatrix.cpp: ���������� ����� ����� ��� ����������� ����������.
//

#include "stdafx.h"
#include "omp.h"


int _tmain(int argc, _TCHAR* argv[])
{
	int n = 100; 
	int m = 1200;
	
	double sum;
	int i, j, k;
	
	double *MatrixA = new double [m*n];
	double *MatrixB = new double [n*m];
	double *MatrixC = new double [m*m];
	
	/*for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			MatrixA[i * n + j] = i + j;
			MatrixB[i * n + j] = j * 3.1;
		}
	}*/
	
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++){
			MatrixA[i * n + j] = i + j;
		}
		
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
		{
			MatrixB[i * m + j] = (i - j) * 5;
		}


	double startTime, endTime;

	startTime = omp_get_wtime();
    
    #pragma omp parallel for private(j, k, sum)
	for(i = 0; i < m; i++)
	{
		for(k = 0; k < m; k++)
		{   
			sum = 0;
			for(j = 0; j < n; j++)
			{
				sum += MatrixA[i * n + j] * MatrixB[j * m + k];
			}
			MatrixC[i * m + k] = sum;
		}
	}
	
	endTime = omp_get_wtime();
	printf("%f", endTime - startTime);

	FILE *f;
		//char name[15] = "\0";
		//sprintf(name, "rank %d.txt", "0");
	f = fopen("answer.txt", "w");
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < m; j++)
			fprintf(f, "%.3f ", MatrixC[i * m + j]);
		fprintf(f, "\n");
	}
	fprintf(f, "\ntime = %f\n", endTime - startTime);
	
	fclose(f);
	
	getchar();
	
	return 0;
}

